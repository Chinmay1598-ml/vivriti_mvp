# Vivriti MVP

End-to-end local RAG-based assistant.